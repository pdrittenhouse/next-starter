<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', 'root' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'yv+LGX+Ku/WMK54gYcZVL8Lgd72HgQdGtvkOqWL2i/SBZ7PxqoLG2VBEoN4FShuaobIPplstTWR53ttSC+dWxQ==');
define('SECURE_AUTH_KEY',  'u1XjRC//AytkwoLCG0z5U1dzeI1LUvKuE/Acr47MpKnEphofORosI91SNlBQJ+S+mgaLQG61ib6bfKas5gKUJA==');
define('LOGGED_IN_KEY',    'wv7FZUidyjjTcpgBp2NF5KeCMv+e8vk0ae4BtBvsFlyXVvLZwdAZWnuhQ6FCcmTGgU9JaU7DjdsWJxCZMgFbWQ==');
define('NONCE_KEY',        'EYhu+mcrvT9j7ZuMr5TBNOzcJ2JUQkiNaSHkqtazWZibPf4pQ1OWvlEsakYGUFYwoEgmbO+3rKvQS/LiMozC0w==');
define('AUTH_SALT',        'bBmBBLgPeEN/2bLczzprHAcVp3x4nKc37dPpNi6tT1kiN9Z0De7WKlF+VPqE+kXmZAoumAj0l1yejA3uKm+8qA==');
define('SECURE_AUTH_SALT', 'HgG4HQ1tG0US6DYyTGX2GWvWukuwe/JeEuqkK7ykHJfTXY0GHakUjpVBnvbhhYWSQK573KON92UYWE0nHA192A==');
define('LOGGED_IN_SALT',   'wanOgS2d4w1/CcZg7fmV56fbOUkqnAddV/1cysBkAuk/GnEDMlznlyi0xL+4Q7oPbgtPdT/bgoCiY5NX0v98Hw==');
define('NONCE_SALT',       'akF/VW06YoZcgPUZ/ooww7TzAjcIQus0NpmD9MUaoJLORkTBkrjhEg1zTAE0VnttwfiakQB47UtZAmOkT8wj/A==');

define( 'WP_MEMORY_LIMIT', '512M' );

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




define( 'WP_ENVIRONMENT_TYPE', 'local' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
